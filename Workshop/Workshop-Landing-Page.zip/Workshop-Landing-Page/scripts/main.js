import { slickMarkup, slickPlugin } from "./slickHTMLmarkup.js";
import { dateTimeClickEvent } from "./dateTimePicker.js";

slickMarkup();
slickPlugin();

dateTimeClickEvent();

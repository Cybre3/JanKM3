function dateTimeClickEvent() {
    const dateTimeBox = document.getElementById("dateTimeInput");
    dateTimeBox.addEventListener("click", dateTimePlug);
    console.log(dateTimeBox);
}

function dateTimePlug() {
    jQuery("#dateTimeInput").datetimepicker({
        format: "d.m.Y H:i",
        inline: true,
        lang: "ru",
    });
}

export { dateTimeClickEvent };
